import { Component } from '@angular/core';

@Component({
  selector: 'app-not-found-404',
  standalone: true,
  imports: [],
  templateUrl: './not-found-404.component.html',
  styleUrl: './not-found-404.component.scss'
})
export class NotFound404Component {

}
