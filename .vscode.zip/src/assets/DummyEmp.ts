export const dummyEmp = [
  {
    "employeeId": 1,
    "employeeName": "John Doe",
    "email": "john.doe@example.com",
    "contactNumber": "123-456-7891",
    "gender": "male",
    "skills": [
      { "name": "JavaScript", "experience": "Intermediate" },
      { "name": "HTML", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 2,
    "employeeName": "Jane Smith",
    "email": "jane.smith@example.com",
    "contactNumber": "123-456-7892",
    "gender": "female",
    "skills": [
      { "name": "Java", "experience": "Intermediate" },
      { "name": "SQL", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 3,
    "employeeName": "Michael Johnson",
    "email": "michael.johnson@example.com",
    "contactNumber": "123-456-7893",
    "gender": "male",
    "skills": [
      { "name": "Python", "experience": "Intermediate" },
      { "name": "CSS", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 4,
    "employeeName": "Emily Brown",
    "email": "emily.brown@example.com",
    "contactNumber": "123-456-7894",
    "gender": "female",
    "skills": [
      { "name": "C++", "experience": "Intermediate" },
      { "name": "Angular", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 5,
    "employeeName": "William Davis",
    "email": "william.davis@example.com",
    "contactNumber": "123-456-7895",
    "gender": "male",
    "skills": [
      { "name": "Ruby", "experience": "Intermediate" },
      { "name": "React", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 6,
    "employeeName": "Olivia Wilson",
    "email": "olivia.wilson@example.com",
    "contactNumber": "123-456-7896",
    "gender": "female",
    "skills": [
      { "name": "PHP", "experience": "Intermediate" },
      { "name": "Node.js", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 7,
    "employeeName": "James Martinez",
    "email": "james.martinez@example.com",
    "contactNumber": "123-456-7897",
    "gender": "male",
    "skills": [
      { "name": "Swift", "experience": "Intermediate" },
      { "name": "iOS Development", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 8,
    "employeeName": "Sophia Anderson",
    "email": "sophia.anderson@example.com",
    "contactNumber": "123-456-7898",
    "gender": "female",
    "skills": [
      { "name": "Kotlin", "experience": "Intermediate" },
      { "name": "Android Development", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 9,
    "employeeName": "Benjamin Taylor",
    "email": "benjamin.taylor@example.com",
    "contactNumber": "123-456-7899",
    "gender": "male",
    "skills": [
      { "name": "Go", "experience": "Intermediate" },
      { "name": "Docker", "experience": "Advanced" }
    ]
  },
  {
    "employeeId": 10,
    "employeeName": "Ava Thomas",
    "email": "ava.thomas@example.com",
    "contactNumber": "123-456-78910",
    "gender": "female",
    "skills": [
      { "name": "TypeScript", "experience": "Intermediate" },
      { "name": "Vue.js", "experience": "Advanced" }
    ]
  }
]
